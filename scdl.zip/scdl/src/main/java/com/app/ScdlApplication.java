package com.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.app.repository.StudentRepository;
import com.app.repository.TeacherRepository;
@SpringBootApplication
public class ScdlApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(ScdlApplication.class, args);
	}

	@Autowired
	private StudentRepository studentRepository;
	private TeacherRepository teacherRepository;
	
	@Override
	public void run(String... args) throws Exception {
		
	
		
	}

}
