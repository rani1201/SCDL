package com.app.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.app.dto.UserRegistrationDto;
import com.app.entity.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
